let lastNumber = 10;
let sum=0;

let i; 
for(i=0; i<=lastNumber; i++)
{
    sum+=i;
}

console.log("Сумма чисел от 1 до ", lastNumber, "Ожидаю результат", sum);