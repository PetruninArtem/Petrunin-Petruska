let number = 123;
let quantity =0;

while(number !=0)
{
    number=Math.floor(number/10);
    quantity++;
}

console.log(quantity);
