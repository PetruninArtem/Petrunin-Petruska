let startNumber = 1;
let multiplier= 4;
let quantity = 7;

let i;
for(i=0; i < quantity; i++)
{
    startNumber=startNumber*multiplier;
    console.log(startNumber);
}