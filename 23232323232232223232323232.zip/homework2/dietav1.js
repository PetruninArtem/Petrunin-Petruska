let initialWeight =56000;
let targetWeight = 45000;
let b = 0;
let days = 0;

while(initialWeight !=targetWeight)
{
    b=(initialWeight*5)/100;

    initialWeight=b;

    days++;
}

console.log("Начальный вес ", initialWeight, " гр., хотим похудеть до ", targetWeight," гр. Ожидаю ответ ", days);