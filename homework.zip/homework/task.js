//let optimalTime = 80;
//let walkTime = 80;

/*if(walkTime>=optimalTime) {
    console.log('Прогулка достаточно длинная');
}
else {
    console.log('Нужно еще погулять');
}

console.log(true<=0);
console.log('2'>'1');
console.log('прогулка'>'ПРОГУЛКА');

let string ='123';
let number = 123;

console.log(string === String(number));
console.log(Number(string) === number);
*/

/*let optimalTime = 80;
let walkTime = 20;
let timeLeft;

if(walkTime>=optimalTime) {
    timeLeft=0;
}
else { 
    timeLeft = optimalTime - walkTime;
}

console.log('Осталось еще гулять', timeLeft, 'минут');*/

/*let onVacation;

if(onVacation){
    console.log('Проект нельзя выполнить');
}
else{
    console.log('Проект можно выполнить');
}*/

let enoughDevelopers = true; //если true может вывести два сообщения
let techAvailable = true;   //если true может вывести два сообщения
let message ='Проект нельзя выполнить';
let onVacation = true;
let onSickLeave = false;

if(enoughDevelopers && techAvailable && !onVacation && !onSickLeave) {
    message ='Проект можно выполнить';
}
else {
    message = "Проект нельзя выполнить";
}

console.log(message);

